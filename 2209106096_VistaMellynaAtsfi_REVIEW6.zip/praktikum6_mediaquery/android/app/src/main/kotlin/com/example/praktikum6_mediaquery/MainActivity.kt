package com.example.praktikum6_mediaquery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
